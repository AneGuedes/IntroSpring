package br.com.ane.introAppAne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroAppAneApplicationTests {

	@Test
	void contextLoads() {
	}

}
