package br.com.ane.introAppAne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntroAppAneApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntroAppAneApplication.class, args);
	}

}
